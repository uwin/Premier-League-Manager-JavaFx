package Model;

public  interface LeagueManager{
	void createClub(String name, String location);
	void deleteClub(int index);
	void viewClub(int index);
	void displayTable();
	void addMatch(Match match);
	void save();
	void load();
}