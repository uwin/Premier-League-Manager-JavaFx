package Model;

import java.util.ArrayList;
import java.util.List;
public class PremierLeagueManager implements LeagueManager{

	static List <SportsClub> clubList= new ArrayList<>();
	static List <Match> matchList = new ArrayList<>();

	private static PremierLeagueManager instance= null;

	private PremierLeagueManager(){}
	public static PremierLeagueManager getInstance(){
		if (instance== null){
			synchronized (PremierLeagueManager.class){
				if(instance==null)instance = new PremierLeagueManager();
			}
		}return instance;
	}

	public static void main(String[]args) {}

	@Override
	public void createClub(String name, String location) { }
	@Override
	public void deleteClub(int index) { }
	@Override
	public void viewClub(int index) { }
	@Override
	public void displayTable() { }
	@Override
	public void addMatch(Match match) { }
	@Override
	public void save() { }
	@Override
	public void load() { }

	public List<SportsClub> getClubList() {
		return clubList;
	}
	public List<Match> getMatchList() { return matchList; }

	public static void setClubList(List<SportsClub> clubList) {
		PremierLeagueManager.clubList = clubList;
	}

	public static void setMatchList(List<Match> matchList) {
		PremierLeagueManager.matchList = matchList;
	}
}