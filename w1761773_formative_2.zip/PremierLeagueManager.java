import java.util.ArrayList;
import java.util.List;
public class PremierLeagueManager implements LeagueManager{

	static List <FootballClub> clubList= new ArrayList<FootballClub>();
	static List <Match> matchList = new ArrayList<Match>();
	public static void main(String[]args){

	}

	public void createClub(String name, String location) {
		FootballClub newClub = new FootballClub(name,location);
		clubList.add(newClub);

		System.out.println("----|");
		System.out.println("Added club : "+ newClub.getName());
		System.out.println("----|");

	}

	public void deleteClub(int index) {
		String Name = clubList.get(index).getName();

		System.out.println("----|");
		System.out.println("Deleted club : "+Name);
		System.out.println("----|");
		
		clubList.remove(index);
	}

	public void viewClub(int index) {}

	public void displayTable() {}

	public void addMatch(Match match) {
		matchList.add(match);
	}

	public void save() {
		Serialize save = new Serialize();
		save.serialize(clubList,matchList);
	}
	public void load() {
		Serialize load = new Serialize();
		load.deserialize();
	}

	public List<FootballClub> getClubList() {
		return clubList;
	}
	public List<Match> getMatchList() { return matchList; }

	public void setClubList(List<FootballClub> clubList) {
		this.clubList = clubList;
	}
	public void setMatchList(List<Match> matchList1){
		this.matchList = matchList1;
	}
}