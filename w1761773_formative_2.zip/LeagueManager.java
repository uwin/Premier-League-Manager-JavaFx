interface LeagueManager{

	public void createClub(String name, String location);
	public void deleteClub(int index);
	public void viewClub(int index);
	public void displayTable();
	public void addMatch(Match match);
	public void save();
	public void load();
}