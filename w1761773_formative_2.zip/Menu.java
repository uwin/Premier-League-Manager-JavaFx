import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;
import java.util.Collections;

public class Menu{
	public static void main(String [] args){
        Menu begin = new Menu();
        begin.load();
        begin.menuCli();
	}
    public void menuCli (){
        Scanner sc = new Scanner(System.in);
        System.out.println(" --------------------------------");
        System.out.println(" 1 | Create Football club");
        System.out.println(" 2 | Delete Football club");
        System.out.println(" 3 | Display statistics");
        System.out.println(" 4 | Display Premier league Table");
        System.out.println(" 5 | Played match");
        System.out.println(" 6 | Exit");
        System.out.println(" --------------------------------");
        System.out.println("Select Option");
        String selection;
        selection = sc.next();

        switch (selection){
            case "1":
                createClub();
                pause();
                break;
            case "2":
                deleteClub();
                pause();
                break;
            case "3":
                viewClub();
                pause();
                break;
            case "4":
                displayTable();
                pause();
                break;
            case "5":
                addMatch();
                pause();
                break;
            case "6":
                save();
                System.exit(0);
            default:
                menuCli();
                break;
        }
    }
    public void pause(){
	    Scanner sc = new Scanner(System.in);
	    System.out.print("\ncontinue... (press any key) ");
	    String in = sc.next();
	    if (!in.isEmpty()) menuCli();
    }
    public void createClub() {
//        FootballClub newClub= new FootballClub();
        PremierLeagueManager club = new PremierLeagueManager();
        List <FootballClub> clubList = club.getClubList();
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Name for Club");
        String name = sc.nextLine();

        for(FootballClub clubLoop: clubList){
            if (clubLoop.getName().equalsIgnoreCase(name)){
                System.out.println("the Club already exists");
                createClub();
                return;
            }
        }

        System.out.println("Enter Location for Club");
        String location = sc.nextLine();
        club.createClub(name,location);
    }
    public void deleteClub() {
        PremierLeagueManager club = new PremierLeagueManager();
        System.out.println("Select Name for Club");
        int selectedClub = SelectTeam();
        club.deleteClub(selectedClub);
//        delete match
//        FootballClub A;
//        FootballClub B;
//        List deleteList = new ArrayList();
//        for (Match m: matchList){
//            A = m.getTeamA();
//            B = m.getTeamB();
//
//            if (clubList.get(selectClub).getScore() > m.getTeamAScore()) {
//                B.setWins(B.getWins()-1);
//                B.setPointCount(B.getPointCount()-1);
//                A.setDefeat(A.getDefeat()-1);
//            }else if (clubList.get(selectClub).getScore() > m.getTeamBScore()){
//                A.setWins(A.getWins()-1);
//                A.setPointCount(A.getPointCount()-3);
//                B.setDefeat(B.getDefeat()-1);
//            }else {
//                A.setDraws(A.getDraws()-1);
//                B.setDraws(A.getDraws()-1);
//                A.setPointCount(A.getPointCount()-1 );
//                B.setPointCount(B.getPointCount()-1 );
//            }
//            matchList
//
//            if (clubList.get(selectClub).getName().equals(A.getName())){
//                deleteList.add(matchList.indexOf(m));
//
//            }else if (clubList.get(selectClub).getName().equals(B.getName())){
//                deleteList.add(matchList.indexOf(m));
//            }
//        }


//        send to main

    }

    public void viewClub() {
        Scanner sc = new Scanner(System.in);
        PremierLeagueManager club = new PremierLeagueManager();
    	List <FootballClub> clubList = club.getClubList();
	    if(clubList.size()<=0){
            System.out.println("no clubs in league");
            pause();
		    return;
	    }
        System.out.println("Select Name for Club");
        FootballClub clubP = clubList.get(SelectTeam());
        System.out.println(clubP);

    }
    public void displayTable() {

        PremierLeagueManager club = new PremierLeagueManager();
        List <FootballClub> clubList=club.getClubList();
        if(clubList.size()<=0){
            System.out.println("no clubs in league");
            pause();
            return;
        }
        Collections.sort(clubList);
        Collections.reverse(clubList);
        String sFormat = "|%1$-16s|%2$-10s|%3$-10s|%4$-10s|%5$-10s|%6$-10s|\n";
        System.out.format(sFormat,"Name","Points","Goals","Wins","Loss","Matches");
        for (FootballClub l: clubList){
            System.out.format(sFormat,l.getName(),l.getPointCount(),l.getGoalsScored(),l.getWins(),l.getDefeat(),l.getMatchCount());
        }


    }
    public void addMatch() {

		PremierLeagueManager club = new PremierLeagueManager();
    	List<FootballClub> clubList = club.getClubList();

    	if(clubList.size()<=1){
            System.out.print("you need atleast 2 club to add a match");
            pause();
            return;
        }

    	Scanner sct = new Scanner(System.in);

        System.out.println("Enter date [DD-MM-YYYY]: ");
        String line = sct.nextLine();
        Date date = null;
        while(true){
        try {
            date = new SimpleDateFormat("DD-MM-YYYY").parse(line);
            break;
        } catch (ParseException ex) {
            System.out.println("incorrect format, try again");
            line = sct.nextLine();
            }
        }

        System.out.println(" --------------------------------");
        System.out.println("select First club name");
        FootballClub oneClub = clubList.get(SelectTeam());
		
		System.out.println(" --------------------------------");
        System.out.println("select Second club name");
        FootballClub twoClub = clubList.get(SelectTeam());
        

        while (oneClub==twoClub){
        	System.out.println(" --------------------------------");
            System.out.println("| >|Select a different team|< |");
            twoClub = clubList.get(SelectTeam());

        }

        oneClub.setMatchCount(oneClub.getMatchCount()+1);
        twoClub.setMatchCount(twoClub.getMatchCount()+1);

        Scanner sc = new Scanner(System.in);

        System.out.println("enter Score for "+oneClub.getName());
        while (!sc.hasNextInt()){
            String  b = sc.next();
            System.out.println("enter in number");
        }
        int oneClubScore = sc.nextInt();
        oneClub.setScore(oneClub.getScore()+oneClubScore);

        System.out.println("enter Score for "+twoClub.getName());
        while (!sc.hasNextInt()){
            String  b = sc.next();
            System.out.println("enter in number");
        }
        int twoClubScore = sc.nextInt();
        twoClub.setScore(twoClub.getScore()+twoClubScore);

        Match match = new Match();
        match.setDate(date);
        match.setTeamA(oneClub);
        match.setTeamB(twoClub);
        match.setTeamAScore(oneClubScore);

        if (oneClubScore >twoClubScore) {
            oneClub.setWins(oneClub.getWins()+1);
            oneClub.setPointCount(oneClub.getPointCount()+3);
            twoClub.setDefeat(twoClub.getDefeat()+1);
        }else if (twoClubScore > oneClubScore){
            twoClub.setWins(twoClub.getWins()+1);
            twoClub.setPointCount(twoClub.getPointCount()+3);
            oneClub.setDefeat(oneClub.getDefeat()+1);
        }else {
            oneClub.setDraws(oneClub.getDraws()+1);
            twoClub.setDraws(twoClub.getDraws()+1);
            oneClub.setPointCount(oneClub.getPointCount()+1);
            twoClub.setPointCount(twoClub.getPointCount()+1);
        }

        oneClub.setGoalsScored(oneClub.getGoalsScored()+oneClubScore);
        twoClub.setGoalsReceived(twoClub.getGoalsReceived()+oneClubScore);

        twoClub.setGoalsScored(twoClub.getGoalsScored()+twoClubScore);
        oneClub.setGoalsReceived(oneClub.getGoalsReceived()+twoClubScore);

        club.addMatch(match);
    }
    public void save()  {
        PremierLeagueManager clubList = new PremierLeagueManager();
        clubList.save();
    }
    public void load() {
        PremierLeagueManager clubList = new PremierLeagueManager();
        clubList.load();
    }
    public int SelectTeam (){
        ArrayList tempMenu = new ArrayList();
        Scanner sc = new Scanner(System.in);
        int i=0;
        PremierLeagueManager tempList = new PremierLeagueManager();
        List<FootballClub>  clubList=tempList.getClubList();
        for (FootballClub l: clubList){
            System.out.println(i +"| "+ l.getName());
            tempMenu.add(String.valueOf(i));
            i++;
        }
        String selectClub = sc.next();
        while(!tempMenu.contains(selectClub)){
        	System.out.println("wrong input");
            selectClub = sc.next();
            System.out.println(selectClub);
        }
	    return Integer.parseInt(selectClub);
    }

}