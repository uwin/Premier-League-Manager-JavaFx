import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class Serialize implements Serializable {
	public void serialize(List<FootballClub> clubList,List<Match> matchList) {
		ArrayList<Object> data=new ArrayList<>();

		try(FileOutputStream fileOut = new FileOutputStream("data.ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut)
		){  data.add(clubList);
		    data.add(matchList);
		    out.writeObject(data);
		    
		    System.out.println("----|");
			System.out.println("Data Saved");
			System.out.println("----|");

		} catch (FileNotFoundException e){
		      e.printStackTrace();
		      return;
		} catch (IOException i){
			i.printStackTrace();
			return;
		}
	}
	public void deserialize() {
		ArrayList<Object> deserialized=new ArrayList<>();
	
		List<FootballClub> newArrayClub = new ArrayList<FootballClub>();
		List<Match> newArrayMatch = new ArrayList<Match>();

		try(FileInputStream fileIn = new FileInputStream("data.ser");
			ObjectInputStream in = new ObjectInputStream(fileIn)
		){
			deserialized = (ArrayList) in.readObject();
			PremierLeagueManager load = new PremierLeagueManager();
			load.setClubList((List<FootballClub>) deserialized.get(0));
			load.setMatchList((List<Match>) deserialized.get(1));

			System.out.println("----|");
			System.out.println("Data Loaded");
			System.out.println("----|");

		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("----|");
			System.out.println("Data not available to load");
			System.out.println("----|");
			return;
		} catch (IOException i) {
			i.printStackTrace();
			return;
		} catch (ClassNotFoundException c) {
			c.printStackTrace();
			return;
		} catch (Exception e){
			e.printStackTrace();
			return;
		}
	}
}