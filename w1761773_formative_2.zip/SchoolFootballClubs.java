import java.io.Serializable;
public class SchoolFootballClubs extends FootballClub implements Serializable {

	public SchoolFootballClubs() {
	}

	public SchoolFootballClubs(String name, String location) {
		super(name, location);
	}

	public SchoolFootballClubs(String name, String location, int wins, int draws, int defeat, int goalsReceived, int goalsScored, int score, int pointCount, int matchCount) {
		super(name, location, wins, draws, defeat, goalsReceived, goalsScored, score, pointCount, matchCount);
	}
}