import java.io.Serializable;
import java.util.Comparator;
import java.util.Objects;

public class FootballClub extends SportsClub implements Serializable, Comparable<FootballClub> {
	private int wins;
	private int draws;
	private int defeat;
	private int goalsReceived;
	private int goalsScored;
	private int score;
	private int pointCount;
	private int matchCount;

	@Override
	public String toString() {
		return  " \nname          : " + name +
				" \nlocation      : " + location +
				" \nwins          : " + wins +
				" \ndraws         : " + draws +
				" \ndefeat        : " + defeat +
				" \ngoalsReceived : " + goalsReceived +
				" \ngoalsScored   : " + goalsScored +
				" \nscore         : " + score +
				" \npointCount    : " + pointCount +
				" \nmatchCount    : " + matchCount;
	}
	
    public FootballClub(){}

	public FootballClub(String name,String location){
		this.name=name;
		this.location=location;
	}

    public FootballClub(String name,String location,int wins, int draws, int defeat, int goalsReceived,
						int goalsScored, int score, int pointCount, int matchCount) {
		this.name=name;
		this.location=location;
		this.wins = wins;
		this.draws = draws;
		this.defeat = defeat;
		this.goalsReceived = goalsReceived;
		this.goalsScored = goalsScored;
		this.score = score;
		this.pointCount = pointCount;
		this.matchCount = matchCount;
	}

	public int getWins() { return wins; }

	public void setWins(int wins) {
		this.wins += wins;
	}

	public int getDraws() {
		return draws;
	}

	public void setDraws(int draws) { this.draws += draws; }

	public int getDefeat() {
		return defeat;
	}

	public void setDefeat(int defeat) {	 this.defeat += defeat; }

	public int getGoalsReceived() {
		return goalsReceived;
	}

	public void setGoalsReceived(int goalsReceived) {
		this.goalsReceived += goalsReceived;
	}

	public int getGoalsScored() {
		return goalsScored;
	}

	public void setGoalsScored(int goalsScored) {
		this.goalsScored += goalsScored;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score += score;
	}

	public int getPointCount() {
		return pointCount;
	}

	public void setPointCount(int pointCount) {
		this.pointCount += pointCount;
	}

	public int getMatchCount() {
		return matchCount;
	}

	public void setMatchCount(int matchCount) {
		this.matchCount += matchCount;
	}

	@Override
	public int compareTo(FootballClub o) {
		int comparePoints=((FootballClub)o).getPointCount();
		return this.pointCount-comparePoints;
	}

//	@Override
//	public int hashCode() {
//		return Objects.hash(wins, draws, defeat, goalsReceived, goalsScored, score, pointCount, matchCount);
//	}

}