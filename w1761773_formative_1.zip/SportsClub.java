import java.io.Serializable;
import java.util.Objects;

class SportsClub implements Serializable {
	String name;
	String location;

	public SportsClub(String name, String location) {
		this.name = name;
		this.location = location;
	}

	public SportsClub(){}

	public String getName() { return name; }
	public void setName(String name) { this.name=name;	}

	public String getLocation() { return location; }
	public void setLocation(String location) { this.location=location;	}

//	public int hashCode() {
//		return Objects.hash(name,location);
//	}
}