import java.io.Serializable;
public class UniversityFootballClub extends FootballClub implements Serializable {

	public UniversityFootballClub() {
	}

	public UniversityFootballClub(String name, String location) {
		super(name, location);
	}

	public UniversityFootballClub(String name, String location, int wins, int draws, int defeat, int goalsReceived, int goalsScored, int score, int pointCount, int matchCount) {
		super(name, location, wins, draws, defeat, goalsReceived, goalsScored, score, pointCount, matchCount);
	}
}