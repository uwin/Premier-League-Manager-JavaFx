package Model;

public class UniversityFootballClub extends FootballClub{

	public UniversityFootballClub() {
	}

	public UniversityFootballClub(String name, String location) {
		super(name, location);
	}
}