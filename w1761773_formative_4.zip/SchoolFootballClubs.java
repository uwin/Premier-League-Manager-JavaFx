package Model;

public class SchoolFootballClubs extends FootballClub {

	public SchoolFootballClubs() {
	}

	public SchoolFootballClubs(String name, String location) {
		super(name, location);
	}
}